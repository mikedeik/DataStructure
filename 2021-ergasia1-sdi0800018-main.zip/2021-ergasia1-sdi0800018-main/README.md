# Homework1

Download the homework1 description file from:

http://cgi.di.uoa.gr/~k08/manolis/2020-2021/homework/Εργασία-1-2021.pdf

# Μιχάλης Δεικτάκης
# ΑΜ : 1115200800018

Έχω γράψει readme files σε κάθε άσκηση που έχω απαντήσει στον αντίστοιχο φάκελο.
Ελπίζω να είναι σωστό και να βοηθήσει πιο πολύ με την κάθε άσκηση.
