/* This code is from Chapter 4 of the book "Algorithms in C" by Robert Sedgewick. */

void STACKinit(int);
 int STACKempty();
void STACKpush(Item);
Item STACKpop();
