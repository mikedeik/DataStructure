/* This is the file StackTypes.h   */

typedef char ItemType;
/* char is the type for our first application */
/* float is the type for our second application */


