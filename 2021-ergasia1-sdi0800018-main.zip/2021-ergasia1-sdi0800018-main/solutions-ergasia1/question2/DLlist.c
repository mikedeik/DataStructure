
#include "stdio.h"
#include "stdbool.h"
#include "stdlib.h"
#include "DLlist.h"

struct node                                     // struct node consists of an element it holds a pointer to next and one to previous node
{
    elem data;
    struct node* next;
    struct node* prev;
    
};

struct List                                     // struct List consists of a head and tail node plus a int tha counts the ammount of nodes inside
{
    DLLnode *head;
    DLLnode *tail; 
    int size;

};

DLLnode* CreateNode(elem d){                    // a fuction to initialize a Node 

    DLLnode* n;
    n = malloc(sizeof(DLLnode));
    n->data = d;
    n->next = NULL;
    n->prev = NULL;

    return n;
}

void DeleteNode(DLLnode* n){                    // deletes node by deallocating memmory if the node wasn't inserted in the list

    free(n);
}


list* create(){                                 // creates a double linked list by allocating the memmory needed

    list* mylist;
    mylist = malloc(sizeof(list));
    mylist->head = malloc(sizeof(DLLnode));
    mylist->head = malloc(sizeof(DLLnode));
    mylist->head = CreateNode(0);
    mylist->tail = CreateNode(0);

    mylist->head->next = mylist->tail;          // and creates the links between head and tail node
    mylist->tail->prev = mylist->head;
    mylist->size =0;
    return mylist;                              // returns a pointer to a list



}

void DeleteList(list* l){                       // frees memory used by the linked list

    DLLnode* temp;
    temp = l->head;

    while(temp->next != NULL){
        temp = temp->next;
        free(temp->prev);
    }
    free(l->tail);
    free(l);


}


int Size(list* l){                              // returns the size of the list

    return l->size;    
}

int IsEmpty(list* l){                           // returns 1 if list is empty else returns 0

    return (l->size == 0);
}

DLLnode* GetFirst(list* l){                     // returns the first node of the list by creating a new node with the same data as the next of head node       

    DLLnode* temp;                              
    temp = CreateNode(l->head->next->data);
    return temp;

}

DLLnode* GetLast(list* l){                      // returns last node by creating a new node with same data as the previous of the tail

    DLLnode* temp;
    temp = CreateNode(l->tail->prev->data);
    return temp;
}

DLLnode* GetPrev(DLLnode* n, list* l){         // using a temporary pointer to node, we search the list up to the given node and return the node before      

    

    DLLnode* temp;
    temp = l->head->next;
    for(int i = 0; i<l->size; i++){
        if(n == temp){
            if(temp->prev == l->head) {        // if given node is first node we inform the user that there is no previous node 
                printf("Given Node is first Node! NULL returned! \n");
                temp = NULL;
            }
            else{
                temp = CreateNode(temp->prev->data);       // creating a node with the same data to return

            }           
            break;
        }
        temp = temp->next;
        
    }



    return temp;


}
DLLnode* GetNext(DLLnode* n, list* l){        // using a temporary pointer to node, we search the list up to the given node and return the node after            

    DLLnode* temp;
    temp = l->head;
    for (int i =0; i< l->size ; i++){
        if (temp == n){
            if(temp->next == l->tail){              // if given node is last node we inform the user that there is no next node 
                printf("Given node is the last node! NULL returned! \n"); 
                temp = NULL;
            }
            else{
                temp = CreateNode(temp->next->data);        // creating a node with the same data to return

            }
            
            break;
        }
        temp = temp->next;
    }
    
    return temp;
    
}


void AddFirst(DLLnode* n, list* l){                         // adds a given node at the start of the list

    DLLnode* temp;
    temp = l->head->next;
    while(temp != l->tail){

        if(temp == n){
            break;
        }
        temp = temp->next;                                  // we check if given node is allready in the list 

    }
    if(temp != l->tail){
        printf(" Node is allready in the list \n");         
    }
    else{
        n->next = l->head->next;                            // if not node gets inserted and size increments by 1
        l->head->next->prev = n;                            
        n->prev = l->head;
        l->head->next = n;
        l->size += 1;
    }

}

void AddLast(DLLnode* n, list* l){                          // adds a given node at the end of the list

    DLLnode* temp;
    temp = l->head->next;
    while(temp != l->tail){

        if(temp == n){
            break;
        }
        temp = temp->next;

    }
    if(temp != l->tail){
        printf(" Node is allready in the list \n");           // we check if given node is allready in the list 
    }
    else{
        n->prev = l->tail->prev;                              // if not node gets inserted and size increments by 1
        l->tail->prev->next = n;
        n->next = l->tail;
        l->tail->prev = n;
        l->size += 1;
    }
}

void AddBefore(DLLnode* z, DLLnode* v, list* l){                // adds a given node before another given node

    DLLnode* temp;
    temp = l->head->next;
    while(temp != l->tail){

        if(temp == z){
            break;
        }
        temp = temp->next;

    }
    if(temp != l->tail){
        printf(" Node is allready in the list \n");             // we check if given node is allready in the list
    }
    else{
        temp = l->head->next;
        while(temp != l->tail){

            if(temp == v){
                break;
            }
            temp = temp->next;
        }

        if( temp == l->tail){
            printf(" Target node is not in this list!");        // if not we check if the target node is in the list
        }
        else{                                                   // if it is we add the node and increment the size of the list by 1
        
            z->prev = v->prev;
            z->next = v;
            z->prev->next = z;
            v->prev = z;
            l->size += 1;

        }
    }
}

void AddAfter(DLLnode* z, DLLnode* v, list* l){            // adds a given node after another given node     
    DLLnode* temp;
    temp = l->head->next;
    while(temp != l->tail){

        if(temp == z){
            break;
        }
        temp = temp->next;

    }
    if(temp != l->tail){
        printf(" Node is allready in the list \n");         // we check if given node is allready in the list
    }
    else{
        temp = l->head->next;
        while(temp != l->tail){

            if(temp == v){
                break;
            }
        temp = temp->next;
        }

        if( temp == l->tail){
            printf(" Target node is not in this list! \n");     // if not we check if the target node is in the list
        }
        else{                                                   // if it is we add the node and increment the size of the list by 1
        
            z->next = v->next;
            z->prev = v;
            v->next->prev = z;
            v->next = z;
            l->size += 1;

        }
    }
}

void Remove(DLLnode* n,list* l){                                // Removes a given node from the list
    DLLnode* temp;
    temp = l->head->next;
    while(temp != l->tail){

        if(temp == n){
            break;
        }
        temp = temp->next;

    }

    if( temp == l->tail){
        printf(" The Given node is not in this list!");         // we check if given node is in the list
    }
    else{                                                       // else we remove it , deallocate the  memmory used for it and decrease size of list by 1
        n->next->prev = n->prev;
        n->prev->next = n->next;
        free(n);
        l->size -= 1;
    }


}





void Print(list* l){                                            // function to print the data of items in the list

    DLLnode* temp;
    temp = l->head;
    for (int i = 0; i < l->size; i++){
        printf("[ %d ] ", temp->next->data );
        temp = temp->next;
        

    }

}






