


typedef int elem;

typedef struct node DLLnode;
typedef struct List list;




list* create();
void DeleteList(list* l);

DLLnode* CreateNode(elem d); 
void DeleteNode(DLLnode* n);        // if a node is created and not inserted in the list, it has to be deleted before the end of main function

int Size(list* l);
int IsEmpty(list* l);

DLLnode* GetFirst(list* l);
DLLnode* GetLast(list* l); 
DLLnode* GetPrev(DLLnode* n, list* l);
DLLnode* GetNext(DLLnode* n, list* l);

void AddFirst(DLLnode* n, list* l);
void AddLast(DLLnode* n, list* l);
void AddBefore(DLLnode* z, DLLnode* v, list* l);
void AddAfter(DLLnode* z, DLLnode* v, list* l);

void Remove(DLLnode* n,list* l);
void Print(list* l);



