

#include "stdio.h"
#include "DLlist.h"
#include "stdlib.h"




int main(){

    list* loi;                              // creating list pointer and some node pointers
    DLLnode* N;
    DLLnode* N1;
    DLLnode* N2;
    DLLnode* N3;
    DLLnode* N4;
    DLLnode* N5;


    N = CreateNode(8);                     // creating nodes and initializing the list
    N1 = CreateNode(3);
    loi = create();
                                        // use of some given funcions

    AddFirst(N,loi);                    
    Print(loi);
    printf("\n");

                                          

    AddFirst(N1, loi);

    Print(loi);
    printf("\n");

    N2 = GetLast(loi);
    AddFirst(N2,loi);

    Print(loi);
    printf("\n");

    N3 = CreateNode(4);

    AddAfter(N3,N,loi);

    AddFirst(N3,loi);
    Print(loi);
    printf("\n");

    N4 = GetNext(N1,loi);

    Remove(N2,loi);

    Print(loi);
    printf("\n");

    AddFirst(N4,loi);
    Print(loi);
    printf("\n");

    N5 = CreateNode(5);
    


    AddAfter(N5,N1,loi);



    Print(loi);
    printf("\n");

 

    DeleteList(loi);    // deleting the list

    return 0; 




}