#include <stdio.h>
#include <stdlib.h>
#include "LL.h"
#include "MAX.h"



void LL_Create(ll_ptr* head){                               // create single linked list

    *head = NULL;


}
int LL_empty(ll_ptr head){                                      // returns if list is empty

    return head == NULL;
}

elem LL_node_data(ll_ptr p){                                    // returns data of given node
    return p->data;
}

void LL_insert_start(ll_ptr * head, elem d){                    // inserts new node at start of list
    ll_ptr newnode;
    newnode = (ll_node*)malloc(sizeof(ll_node));
    newnode->data = d;
    newnode->next = *head;
    *head = newnode;
}


void Print(ll_ptr head){                                        // prints the linked list

    ll_ptr temp;
    temp = head;
    while (temp != NULL){


        printf("[ %d ] " , temp->data);
        temp = temp->next;
    }
}

void delete(ll_ptr* head){

    ll_ptr temp;
    while(*head != NULL){
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }

}

int main(){

    ll_ptr head;

    LL_Create(&head);
    int d;
    printf("Give next integer \n");
    scanf("%d",&d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);    
    
    Print(head);

    printf("\n");

    printf("Highest integer is %d \n ", MAX(head));    // use of MAX function

    delete(&head);
    
    return 0;


}