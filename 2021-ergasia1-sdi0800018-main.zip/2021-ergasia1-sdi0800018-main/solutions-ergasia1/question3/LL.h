
typedef int elem;
typedef struct Node ll_node ;
typedef struct Node* ll_ptr;

struct Node
{
    elem data;
    ll_ptr next;

};