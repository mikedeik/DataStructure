#include <stdio.h>
#include "LL.h"
#include "MAX.h"






int MAX(ll_ptr head){                   // function to find the max integer of a linked list


    ll_ptr temp;                        // temporary node

    temp = head;                        // starts at head
    int max;
    max = head->data;                   // we initialize max as head data    

    if(temp->next == NULL) return max;  // if we are at last node of the list return max
    else{
        temp = head->next;              // temp is next node 
        if (max >= MAX(temp)) return max;       // recursive use of MAX for the next node
        else return MAX(temp);                 
    }    

}