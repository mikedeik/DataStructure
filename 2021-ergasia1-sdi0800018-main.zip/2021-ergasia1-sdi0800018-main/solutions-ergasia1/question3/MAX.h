

int MAX(ll_ptr head);