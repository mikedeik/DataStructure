#include <stdio.h>
#include <stdlib.h>


typedef int elem;
typedef struct Node ll_node ;
typedef struct Node* ll_ptr;



struct Node                                 // node struct
{
    elem data;
    ll_ptr next;

};

void LL_Create(ll_ptr* head){                // list create       

    *head = NULL;


}
int LL_empty(ll_ptr head){                  // returns if empty

    return head == NULL;
}

elem LL_node_data(ll_ptr p){                // returns data
    return p->data;
}

void LL_insert_start(ll_ptr * head, elem d){        // inserts a new node at start 
    ll_ptr newnode;
    newnode = (ll_node*)malloc(sizeof(ll_node));
    newnode->data = d;
    newnode->next = *head;
    *head = newnode;
}


void LL_insert_after(ll_ptr n,elem d){              // inserts a new node after a given node(found by it's data)

    ll_ptr newnode;
    newnode = (ll_node*)malloc(sizeof(ll_node));
    newnode->data = d;
    newnode->next = n->next;
    n->next = newnode;

}

void delete(ll_ptr* head){

    ll_ptr temp;
    while(*head != NULL){
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }

}


void Print(ll_ptr head){                            // prints list

    ll_ptr temp;
    temp = head;
    while (temp != NULL){


        printf("[ %d ] " , temp->data);
        temp = temp->next;
    }
}


void Sort(ll_ptr* head){


    
    ll_ptr new_head = NULL;                 // we create a new head node
    ll_ptr* new_list = &new_head;           // we assign a pointer to this node wich will be our new sorted list
    ll_ptr temp = *head;                    // temporary pointer to the head of given list

    while (temp != NULL )                   
    {
        ll_ptr temp2 = temp->next;          // 2nd temporary pointer to the next node of the one we gonna insert     
        ll_ptr temp3;                         
        if( *new_list == NULL || new_head->data >= temp->data ){        // if the new list is empty or the node data we gonna insert is smaller than head node
            temp->next = *new_list;
            *new_list = temp;               // we put the node at the start of the list                       
        }
        else{                               // else we traverse the list until we find a node with higher data than the one we will insert     
            temp3 = *new_list;              
            while(temp3->next != NULL && temp3->next->data < temp->data){
                temp3 = temp3->next;
            }
            temp->next = temp3->next;           // and we insert it after the previous node (since it's a single linked list)
            temp3->next = temp;
        }
        temp = temp2;                       // after we have inserted the current node we will assign temp to the next node


    }
    
    *head = new_head;                       // at last we set our list (pointer to head node ) to point to the new list
    

    



}



int main(){             // simple main to check the functionallity of the function

    ll_ptr head;

    ll_ptr* list;

    list = &head;

    LL_Create(&head);       // creates list

    int d;
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");         // inserts data
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);
    printf("Give next integer \n");
    scanf("%d",&d);
    LL_insert_start(&head,d);    
    
    Print(head);            // prints list
    printf("\n");

    Sort(list);             // sorts list    

    Print(head);            // print sorted list
    printf("\n");

    delete(list);           // delete list

}