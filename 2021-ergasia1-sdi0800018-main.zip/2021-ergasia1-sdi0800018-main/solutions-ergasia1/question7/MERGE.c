#include <stdio.h>
#include <stdlib.h>


typedef int elem;
typedef struct Node ll_node ;
typedef struct Node* ll_ptr;



struct Node                                 // node struct
{
    elem data;
    ll_ptr next;

};

void LL_Create(ll_ptr* head){                // list create       

    *head = NULL;


}
int LL_empty(ll_ptr head){                  // returns if empty

    return head == NULL;
}

elem LL_node_data(ll_ptr p){                // returns data
    return p->data;
}

void LL_insert_start(ll_ptr * head, elem d){        // inserts a new node at start 
    ll_ptr newnode;
    newnode = (ll_node*)malloc(sizeof(ll_node));
    newnode->data = d;
    newnode->next = *head;
    *head = newnode;
}


void LL_insert_after(ll_ptr n,elem d){              // inserts a new node after a given node(found by it's data)

    ll_ptr newnode;
    newnode = (ll_node*)malloc(sizeof(ll_node));
    newnode->data = d;
    newnode->next = n->next;
    n->next = newnode;

}

void delete(ll_ptr* head){

    ll_ptr temp;
    while(*head != NULL){
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }

}


void Print(ll_ptr head){                            // prints list

    ll_ptr temp;
    temp = head;
    while (temp != NULL){


        printf("[ %d ] " , temp->data);
        temp = temp->next;
    }
}


void Sort(ll_ptr* head){


    
    ll_ptr new_head = NULL;                 // we create a new head node
    ll_ptr* new_list = &new_head;           // we assign a pointer to this node wich will be our new sorted list
    ll_ptr temp = *head;                    // temporary pointer to the head of given list

    while (temp != NULL )                   
    {
        ll_ptr temp2 = temp->next;          // 2nd temporary pointer to the next node of the one we gonna insert     
        ll_ptr temp3;                         
        if( *new_list == NULL || new_head->data >= temp->data ){        // if the new list is empty or the node data we gonna insert is smaller than head node
            temp->next = *new_list;
            *new_list = temp;               // we put the node at the start of the list                       
        }
        else{                               // else we traverse the list until we find a node with higher data than the one we will insert     
            temp3 = *new_list;              
            while(temp3->next != NULL && temp3->next->data < temp->data){
                temp3 = temp3->next;
            }
            temp->next = temp3->next;           // and we insert it after the previous node (since it's a single linked list)
            temp3->next = temp;
        }
        temp = temp2;                       // after we have inserted the current node we will assign temp to the next node


    }
    
    *head = new_head;                       // at last we set our list (pointer to head node ) to point to the new list
    

    



}

ll_ptr MERGE(ll_ptr head1,ll_ptr head2){        // merging 2 lists function with recursion

    ll_ptr new_head = NULL;                     // we create new head node

    if(head1 == NULL) return head2;             // returns the head node of the list that is not empty
    else if(head2 == NULL) return head1;        
                                                // checks the 2 lists witch head data is smaller
    if(head1->data <= head2->data){             // if 1st list head data is smaller than 2nd list
        new_head = head1;                       // sets the new list to point at the head of first list
        new_head->next = MERGE(head1->next,head2);     // for new lists next node calls MERGE again for list 1 starting at next node and list 2      
    }
    else{                                        // does the oposite if 2nd lists head data is smaller   
        new_head = head2;
        new_head->next = MERGE(head1,head2->next);
    }
    return new_head;                            // finally returns the new head node that links to the new list

}



int main(){

    ll_ptr head1;
    ll_ptr* list1;

    list1 = &head1;

    LL_Create(&head1);

    int d;
    printf("Give next integer for first list \n");
    scanf("%d",&d);
    LL_insert_start(&head1,d);
    printf("Give next integer for first list \n");
    scanf("%d",&d);
    LL_insert_start(&head1,d);
    printf("Give next integer for first list \n");
    scanf("%d",&d);
    LL_insert_start(&head1,d);
    printf("Give next integer for first list \n");
    scanf("%d",&d);
    LL_insert_start(&head1,d);

    ll_ptr head2;
    ll_ptr* list2;
    list2 = &head2;
    LL_Create(&head2);

    printf("Give next integer for 2nd list \n");
    scanf("%d",&d);
    LL_insert_start(&head2,d);
    printf("Give next integer for 2nd list \n");
    scanf("%d",&d);
    LL_insert_start(&head2,d);
    printf("Give next integer for 2nd list \n");
    scanf("%d",&d);
    LL_insert_start(&head2,d);
    printf("Give next integer for 2nd list \n");
    scanf("%d",&d);
    LL_insert_start(&head2,d);
    
    Print(head1);
    printf("\n");
    Print(head2);
    printf("\n");               // prints the 2 lists at first

    Sort(list1);
    Sort(list2);

    Print(head1);
    printf("\n");               // prints 2 list after sorting
    Print(head2);
    printf("\n");

    ll_ptr new_head = MERGE(head1,head2);
    Print(new_head);            // prints the new linked list after the merge
    printf("\n");


    delete(&new_head);

}