#include <stdio.h>
#include <stdlib.h>
#include "PQinterface.h"
#include <time.h>


int main(){


    PQ* p;                          // pointer to PQ

    p = init();                     // intializing the PQ

    PQItem my_Array[MAXCOUNT];      // unsorted array

    srand(time(NULL));


    for (int i = 0; i < MAXCOUNT; i++) // filling array with random integers
    {
        my_Array[i] = rand()%100;
    }

    printf("[ ");                      // printing array
    for (int i = 0; i < 10; i++)
    {

        printf("%d ", my_Array[i]);        

    }
    printf("] ");

    printf(" \n");

    for (int i = 0; i < MAXCOUNT; i++)  // inserting all array integers into the pq
    {       
        insert(my_Array[i],p);         
    }



    int j = MAXCOUNT - 1;
    while(j >= 0){                      // popping highest priority integer and inserted in our array backwards

        my_Array[j] = pop(p);
        j--;
    }

    printf("[ ");                       // printing the sorted array
    for (int i = 0; i < 10; i++)
    {

        printf("%d ", my_Array[i]);

    }
    printf("] ");

    printf(" \n"); 



    delete(p);                          // deallocating used memmory

}




