

typedef int PQItem;
typedef struct PriorityQueue PQ;

#define MAXCOUNT 10


PQ* init();
int empty(PQ*);
int full(PQ*);
void insert(PQItem,PQ*);
PQItem pop(PQ*);
void delete(PQ*); 


