# Homework3
Download the homework3 description file from:

http://cgi.di.uoa.gr/~k08/manolis/2020-2021/homework/Εργασία-3-2021.pdf
