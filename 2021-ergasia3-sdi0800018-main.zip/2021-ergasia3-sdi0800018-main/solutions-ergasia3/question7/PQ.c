
#include <stdio.h>
#include <stdlib.h>
#include "PQInterface.h"


struct PriorityQueue{                   // Priority queue using an unsorted array for storing
    
    int count;
    PQItem Array[MAXCOUNT];

};



PQ* init(){                             // initialization of PQ will return a pointer to struct PQ
    PQ* p;
    p = malloc(sizeof(PQ));
    p->count = 0;    
    return p;
}

int empty(PQ* p){                       // returns 1 if empty    

    return (p->count==0);
}

int full(PQ* p){                        // returns 1 if full

    return (p->count == MAXCOUNT);
}

void insert(PQItem item,PQ* p){         // insert on next free 

    if(!full(p)){
        
        p->Array[p->count] = item;
        p->count++;
    }
}

PQItem pop(PQ* p){                       // PQ returns the highest priority item in our case largest integer

    int i;
    int MaxIndex;
    PQItem MaxItem;
    if (!empty(p))
    {
        MaxItem=p->Array[0];
        MaxIndex=0;
        for (i=1; i<p->count; ++i){
            if (p->Array[i] > MaxItem){
                MaxItem= p->Array[i];
                MaxIndex=i;
            }
        }
        p->count--;
        p->Array[MaxIndex] = p->Array[p->count];
        return MaxItem;
    }
    


}
PQItem popfirst(PQ* p){
    int i;
    int first;
    if(!empty(p)){
        first = p->Array[0];
        p->count--;
        for (int i = 0; i < p->count; i++)
        {
            p->Array[i] = p->Array[i+1];
        }
    }
    return first;
}

void delete(PQ* p){                        // dealocates used memmory

    free(p);
}

