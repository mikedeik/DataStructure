

typedef int PQItem;
typedef struct PriorityQueue PQ;

#define MAXCOUNT 20


PQ* init();
int empty(PQ*);
int full(PQ*);
void insert(PQItem,PQ*);
PQItem pop(PQ*);
PQItem popfirst(PQ*);
void delete(PQ*); 


