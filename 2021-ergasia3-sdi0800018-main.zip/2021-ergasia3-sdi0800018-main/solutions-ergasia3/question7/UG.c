#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "UGinterface.h"
#include "PQinterface.h"

#define MAXVERTEX 20


// struct for an edge
struct Edge
{
    vertex vert;
    struct Edge* next;
};

// struct for undirected graph with ADJ list representation
struct UndGraph
{
    int n;
    edge* edges[MAXVERTEX];
    
};

/* a list struct we are going to use later in the UGimplementation array[0] holds
the source vertex while array[1] holds the destination vertex
This not presented in interface as user doesn't need to use it */
typedef struct listnode
{
    int array[2];
    struct listnode* next;
}node;

// init of that list

node* listinit(){

    node* l = malloc(sizeof(node));
    l->next = NULL;
    l->array[0] = 0;
    l->array[1] = 0;
    return l;
}
// freeing space that the list holds
void deletelist(node* h){
    node* temp;

    while (h != NULL)
    {
        temp = h;
        h = h->next;
        free(temp);    
    }
    
}

/* this is the insert list function to insert an edge into the 
back of the list if it's not allready inside */
void insertlist(node* head,int x,int y){
    node* temp;
    temp = head->next;
    bool is_in = false;
    while (temp!=NULL)
    {
        if((temp->array[0] == x && temp->array[1] == y) || (temp->array[1] == x && temp->array[0] == y)) return;
        temp = temp->next;
    }

    temp = head;
    while (temp->next!=NULL)
    {
        temp = temp->next;
    }
    node* newnode = malloc(sizeof(node));
    newnode->array[0] = x;
    newnode->array[1] = y;
    newnode->next = NULL;
    temp->next = newnode;
    
}
/*This is a "print" function for our cause
  It takes 2 lists the tree edges and cross edges
  and will print them separately*/

void showedges(node* l1,node* l2){
    
    node* temp;
    node* temp1;
    temp = l1->next;
    temp1 = l2->next;
    bool is_tree_edge = false;
    if(temp == NULL) printf("No tree edges found \n");
    else{
        printf("Tree edges: \n");
        while (temp != NULL)
        {        
            printf("%d-%d\n",temp->array[0],temp->array[1]); //we print all the tree edges found
            temp = temp->next;
        }
    }
    if(temp1 == NULL) printf("No cross edges found \n");
    else
    {
        printf("Cross edges: \n");
        
        while (temp1 != NULL)        // here we check first if a cross edge is allready a tree edge but presented backwards
        {
            temp = l1->next;
            while (temp != NULL)    // this can happen later in the BFS function since it's an undirected graph
            {                       // so for example a tree edge 1-2 is kept as cross edge 2-1 and we need to exclude that
                if(temp1->array[0] == temp->array[1] && temp1->array[1] == temp->array[0]){
                    is_tree_edge = true;
                    break;
                }

                temp = temp->next;
            }
            
            if(!is_tree_edge) printf("%d-%d\n",temp1->array[0],temp1->array[1]);
            temp1 = temp1->next;
            is_tree_edge = false;

        }
    }
    
    




}

// function to create an edge to insert in the graph (not needed could be part of the insert but this helps the code be clear)

edge* createEdge(int v){
    edge* newedge = malloc(sizeof(edge));
    newedge->next = NULL;
    newedge->vert = v;

    return newedge;

}

/* Function initialize for a graph allocates the memmory for a graph and the ADJ list and inits the edge lists to NULL
   I prefered here to return the initialized graph to a pointer instead of it beeing a parameter 
   Also in this implementation and according to what i understood from the pronunciation the graph is a 0-degree type
   where according to the number N of vertexes input, the vertexes are [0,1,2,...,N-1] */
graph* initialize(int N){

    
    graph* G = malloc(sizeof(graph));
    G->n = N;
    for (int i = 0; i < G->n; i++)
    {
        G->edges[i] = malloc(sizeof(edge));
        G->edges[i] = NULL;

    }    
    return G;

}

/* Function to insert an edge to a graph
   It takes the parameters a graph pointer and 2 vertexes which are 
   the source and destination of the edge  and if it's not allready inside or there is
   no error in the input it creates two edges first will be x-y and 2nd y-x */

void insertedge(graph* g,vertex x,vertex y){


    if((x >= g->n) || (y >= g->n)){
        printf("Error input of edges for the graph \n");
    }
    else{
        edge* temp ;
        for (int i = 0; i < g->n; i++)    
        {
            if (i == x){

                // first checking if the edges have been inserted
                bool allready_in = false;
                temp = g->edges[i];
                while (temp != NULL)
                {
                    if(temp->vert == y){
                        allready_in = true;
                    }
                    temp = temp->next;
                }
                if (allready_in){
                    break;
                } 
                //then we can import the new edge
                
                if (g->edges[i] == NULL){
                    g->edges[i] = createEdge(y);
                }
                else
                {
                    temp = g->edges[i];
                    if (y < (g->edges[i]->vert)){
                        temp = g->edges[i]->next;
                        edge* temp1 = createEdge(y);
                        temp1->next = g->edges[i];
                        g->edges[i] = temp1;
                    }
                    else{
                        while (temp->next != NULL)
                        {
                            if (y < temp->next->vert){
                                edge* temp1 = createEdge(y);
                                temp1->next = temp->next;
                                temp->next = temp1;
                                break;
                            }                        
                            temp = temp->next;
                                               
                        }
                        if(temp->next == NULL){
                            temp->next = createEdge(y);
                        }               
                    }            
                } 
            
                
            }
            if (i == y){
                if (g->edges[i] == NULL){
                    g->edges[i] = createEdge(x);
                }
                else
                {
                    temp = g->edges[i];
                    if (x < (g->edges[i]->vert)){
                        temp = g->edges[i]->next;
                        edge* temp1 = createEdge(x);
                        temp1->next = g->edges[i];
                        g->edges[i] = temp1;
                    }
                    else{
                        while (temp->next != NULL)
                        {
                            if (y < temp->next->vert){
                                edge* temp1 = createEdge(x);
                                temp1->next = temp->next;
                                temp->next = temp1;
                                break;
                            }                        
                            temp = temp->next;
                                               
                        }
                        if(temp->next == NULL){
                            temp->next = createEdge(x);
                        }               
                    }            
                } 
            
                
            } 

        }
    }
    
}

/* Here we have the requested BFS function first it checks if the given vertex is in the graph */
void BreadthFirstSearch(graph* g,vertex x){
    printf("\n");
    printf("Using BFS on vertex: %d \n",x);
    if (x >= g->n) {
        printf("Wrong input of vertex! \n");
        return;
    }
    // we init a queue that we will need for this (this is a Priority Queue implementation from first assignment but i made a new function insert to work like a normal queue)    
    PQ* Q;
    Q = init();
    // we create a boolean array for each vertex that will show if we visited it and some helpfull variables    
    bool visited[g->n];
    vertex v,w;
    edge* curedge;
    // we init the visited array as false
    for (vertex v = 0; v < g->n; v++)
    {
        visited[v] = false;
    }
    // here we use the list implementation from earlier
    // we are gonna insert the found tree-edges and cross edges accordingly 
    node* tree_list = listinit();
    node* cross_list = listinit();
    // first we insert the given vertex into the queue and mark it as visited
    insert(x,Q);
    visited[x] = true;
    // while loop to check if the Q is empty
    while(!empty(Q)){
        // we pop the first element since it's our given vertex
        v = popfirst(Q);
        printf("vertex: %d \n", v);            
        // here we will insert all it's successors into the Q and mark them as visited 
        curedge = g->edges[v];
        while (curedge != NULL)
        {
            w = curedge->vert;
            if(!(visited[w])) {
                // if the vertex is not visited this is a tree edge
                insertlist(tree_list,v,w);
                insert(w,Q);
                visited[w] = true;
            }
            else
            {
                // if it has been visited it's inserted as a cross edge (this is why we need the showedges func to check for a double edge presented backwards)
                insertlist(cross_list,v,w);
            }
            
                
            curedge = curedge->next;
        }
        
    }
    
    
    printf("\n");
    
    // finally calling showedges func to print the requested edges
    showedges(tree_list,cross_list);   
    deletelist(tree_list);
    deletelist(cross_list);

}

/* IsConnected function returns true if the graph is connected or false if it's not
   I used also a print in here for checking that it works correctly
   The way it functions it starts a BFS from any vertex (here 0), and if at the end all
   vertexes are visited returns true or else it returns false
   Since the graph is undirected this works since if it's connected we should be able to reach
   all other vertexes from any given one */
bool IsConnected(graph* g){
    printf("\n");
    PQ* Q;
    Q = init();
    bool visited[g->n];
    bool is_connected = true;
    vertex v,w;
    edge* curedge;
    for (vertex v = 0; v < g->n; v++)
    {
        visited[v] = false;
    }
    insert(0,Q);
    visited[0] = true;
    while(!empty(Q)){
        v = popfirst(Q);
                    

        curedge = g->edges[v];
        while (curedge != NULL)
        {
            w = curedge->vert;
            if(!(visited[w])) {
                
                insert(w,Q);
                visited[w] = true;
            }                
            curedge = curedge->next;
        }       
    }
    for (int i = 0; i < g->n; i++)
    {
        if(!visited[i]) is_connected = false;
    }
    
    if (is_connected) printf("The graph is connected! \n");
    else printf("The graph is not connected! \n");

    return is_connected;


}

/* This is the shortestpaths function
   First checks if the input vertex is correct
   Then we run a BFS as above but for every vertex visited we hold its distance from the given vertex and it's predecessor
   in two different arrays where the index is each vertex and the element hold is accordingly the distance and predecessor
   Using those two arrays we will find the path for each vertex after finishing the BFS */

void shortestpaths(graph*g,vertex x){
    printf("\n");
    if (x >= g->n) {
        printf("Wrong input of vertex! \n");
        return;
    }

    PQ* Q;
    Q = init();
    bool visited[g->n];
    vertex v,w;
    edge* curedge;
    for (vertex v = 0; v < g->n; v++)
    {
        visited[v] = false;
    }
    // the two new arrays where we will hold the distance and predecessor  
    int dist[g->n];
    int pred[g->n];
    for (int i = 0; i < g->n; i++)
    {
        dist[i] = 0; // we init the distance to 0 and predecessor to -1
        pred[i] = -1;
    }
    
    insert(x,Q);
    visited[x] = true;
    // the distance of the vertex we start looking is allready 0 but doesn't matter since we wont check for it
    while(!empty(Q)){
        v = popfirst(Q);
        curedge = g->edges[v];
        while (curedge != NULL)
        {
            w = curedge->vert;
            if(!(visited[w])) {
                insert(w,Q);
                dist[w]+= (dist[v] + 1); // when we insert the vertex in the Q we set the distance equal to 1 + the diastance of it's predecessor's
                pred[w] = v;            // and insert the predecessor in the according array
                visited[w] = true;
            }   
            curedge = curedge->next;
        }
        
    } 

    // after the BFS is done we start a for loor for every vertex
    for (int i = 0; i < g->n; i++)
    {
        if(i == x) continue; // if the vertex is same as the starting we skip it
        if(dist[i] == 0){    // if distance is 0 that means the vertex has not been visited so there is no path to it   
            printf("No path to %d", i);
        } 
        else                // else we will create a helping array that will hold the predecessors since we will need to change it for as many times as the distance
        {
            int help[g->n];
            for (int i = 0; i < g->n; i++)
            {
                help[i] = pred[i];
            }
            int path[dist[i]]; // we init a path array to hold all the vertexes that are in the path // the size should be same a the distance of the vertex
            int count = dist[i] - 1;    // we will use this count to fill the path backwards 
            while (count >= 0)
            {
                path[count] = help[i];  // first at the last spot we insert the first predecessor
                help[i] = help[help[i]]; // then make the predecessor to be it's predecessor's predecessor and so on until we reach our source vertex 
                count--;
            }
            printf("Path from %d to %d : ",x,i);
            for (int j = 0; j < dist[i]; j++)
            {
                printf("%d > ", path[j]); // finally we print the path
            }
            printf("%d" , i);
                
        }
        printf(" \n");
        
    }
      

}
/* Function to print the connected components of the graph
   Here we run a BFS for each vertex of the graph that has not been visited yet and print all the vertexes found
   for each one of them.For each vertex we have a component of the graph and print it.*/

void connectedcomponents(graph* g){
    printf("\n");
    printf("Showing Connected Components of graph \n");
    PQ* Q;
    Q = init();
    bool visited[g->n];
    vertex v,w;
    edge* curedge;
    for (vertex v = 0; v < g->n; v++)
    {
        visited[v] = false;
    }

    for (int i = 0; i < g->n; i++)
    {
        
        if(!visited[i]){
            printf("Component : ");
            insert(i,Q);
            visited[i] = true;
            while(!empty(Q)){
                v = popfirst(Q);
                printf(" %d ", v);            

                curedge = g->edges[v];
                while (curedge != NULL)
                {
                    w = curedge->vert;
                    if(!(visited[w])) {
                        insert(w,Q);
                        visited[w] = true;
                    }
                curedge = curedge->next;
                }
        
            }
            printf("\n");

        }
    }
    
    

}

/*Finally the showgraph function prints the ADJlist of each vertex*/


void showgraph(graph* g){
    for (int i = 0; i < g->n; i++)
    {
        printf("%d : ", i);
        edge* temp = g->edges[i];
        while (temp != NULL)
        {
            printf("%d " , temp->vert);
            temp = temp->next;
        }
        
        printf("\n");
    }   

}


/*Function to free the memmory allocated for the graph*/
void deletegraph(graph* g){

    for (int i = 0; i < g->n; i++)
    {
        while (g->edges[i] !=NULL)
        {
            edge* temp;
            temp = g->edges[i];
            g->edges[i] = g->edges[i]->next;
            free(temp);
        }
        

    }
    free(g);
}