#include <stdbool.h>

typedef int vertex;
typedef struct Edge edge;
typedef struct UndGraph graph;

graph* initialize(int N);
void insertedge(graph* g,int x,int y);
void showgraph(graph* g);
void BreadthFirstSearch(graph* g,vertex x);
bool IsConnected(graph* g);
void shortestpaths(graph*g,vertex x);
void connectedcomponents(graph* g);
void deletegraph(graph* g);