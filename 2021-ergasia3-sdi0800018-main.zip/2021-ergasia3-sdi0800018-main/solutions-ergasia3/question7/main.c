#include <stdio.h>
#include <stdlib.h>
#include "UGinterface.h"





    
    
#define BUFSIZE 1000

int main(int argc, char *argv[])
{
    int s1,s2;
    graph* g;

    int count = 1;
    FILE *fp = fopen(argv[1], "r");

    char buff[BUFSIZE];

    while(fgets(buff, BUFSIZE - 1, fp) != NULL) 
    {
        if(count == 1){
            int n = buff[0] - '0';
            printf("inputing the amount of vertexes %d \n", n);
            g = initialize(n);

        }
        else{
            s1 = buff[0] - '0';
            s2 = buff[2] - '0';

            insertedge(g,s1,s2);

        }
        
        count++;

    }
     
    
    
    showgraph(g);
    BreadthFirstSearch(g,0);
    bool b = IsConnected(g);
    shortestpaths(g,4);
    connectedcomponents(g);
    deletegraph(g);


    fclose(fp);

}
    

