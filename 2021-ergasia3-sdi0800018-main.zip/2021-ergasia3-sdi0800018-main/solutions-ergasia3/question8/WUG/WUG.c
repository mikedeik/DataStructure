#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "WUGinterface.h"


#define MAXVERTEX 20


// struct for an edge
struct Edge
{
    vertex vert;
    weight w;
    struct Edge* next;
};

// struct for undirected graph with ADJ list representation
struct UndGraph
{
    int n;
    edge* edges[MAXVERTEX];
    
};

edge* createEdge(int v, int w){
    edge* newedge = malloc(sizeof(edge));
    newedge->next = NULL;
    newedge->vert = v;
    newedge->w = w;

    return newedge;

}

graph* initialize(int N){

    
    graph* G = malloc(sizeof(graph));
    G->n = N;
    for (int i = 0; i < G->n; i++)
    {
        G->edges[i] = malloc(sizeof(edge));
        G->edges[i] = NULL;

    }    
    return G;

}

/* Function to insert an edge to a graph
   It takes the parameters a graph pointer and 2 vertexes which are 
   the source and destination of the edge  and if it's not allready inside or there is
   no error in the input it creates two edges first will be x-y and 2nd y-x */

void insertedge(graph* g,vertex x,vertex y,weight w){


    if((x >= g->n) || (y >= g->n)){
        printf("Error input of edges for the graph \n");
    }
    else{
        edge* temp ;
        for (int i = 0; i < g->n; i++)    
        {
            if (i == x){

                // first checking if the edges have been inserted
                bool allready_in = false;
                temp = g->edges[i];
                while (temp != NULL)
                {
                    if(temp->vert == y){
                        allready_in = true;
                    }
                    temp = temp->next;
                }
                if (allready_in){
                    break;
                } 
                //then we can import the new edge
                
                if (g->edges[i] == NULL){
                    g->edges[i] = createEdge(y,w);
                }
                else
                {
                    temp = g->edges[i];
                    if (y < (g->edges[i]->vert)){
                        temp = g->edges[i]->next;
                        edge* temp1 = createEdge(y,w);
                        temp1->next = g->edges[i];
                        g->edges[i] = temp1;
                    }
                    else{
                        while (temp->next != NULL)
                        {
                            if (y < temp->next->vert){
                                edge* temp1 = createEdge(y,w);
                                temp1->next = temp->next;
                                temp->next = temp1;
                                break;
                            }                        
                            temp = temp->next;
                                               
                        }
                        if(temp->next == NULL){
                            temp->next = createEdge(y,w);
                        }               
                    }            
                } 
            
                
            }
            if (i == y){
                if (g->edges[i] == NULL){
                    g->edges[i] = createEdge(x,w);
                }
                else
                {
                    temp = g->edges[i];
                    if (x < (g->edges[i]->vert)){
                        temp = g->edges[i]->next;
                        edge* temp1 = createEdge(x,w);
                        temp1->next = g->edges[i];
                        g->edges[i] = temp1;
                    }
                    else{
                        while (temp->next != NULL)
                        {
                            if (y < temp->next->vert){
                                edge* temp1 = createEdge(x,w);
                                temp1->next = temp->next;
                                temp->next = temp1;
                                break;
                            }                        
                            temp = temp->next;
                                               
                        }
                        if(temp->next == NULL){
                            temp->next = createEdge(x,w);
                        }               
                    }            
                } 
            
                
            } 

        }
    }
    
}

void showgraph(graph* g){
    for (int i = 0; i < g->n; i++)
    {
        printf("%d : ", i);
        edge* temp = g->edges[i];
        while (temp != NULL)
        {
            printf("(%d,%d) " , temp->vert,temp->w);
            temp = temp->next;
        }
        
        printf("\n");
    }   

}