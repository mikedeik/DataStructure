typedef int vertex;
typedef int weight;
typedef struct Edgelist adjlist;
typedef struct Edge edge;
typedef struct UndGraph graph;

edge* createEdge(int v, int w);
graph* initialize(int N);
void insertedge(graph* g,vertex x,vertex y,weight w);
void showgraph(graph* g);